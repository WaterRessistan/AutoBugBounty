## Descripción

<!-- Describe brevemente qué cambia este PR y por qué. -->

## Tipo de cambio

- [ ] 🐛 Corrección de bug
- [ ] ✨ Nueva funcionalidad / herramienta
- [ ] ⚡ Mejora de rendimiento
- [ ] 📝 Documentación
- [ ] 🧹 Refactor / limpieza

## Checklist

- [ ] `shellcheck autobb.sh` no reporta hallazgos.
- [ ] `bash -n autobb.sh` pasa sin errores.
- [ ] Las herramientas nuevas se invocan con `grun` y degradan si faltan.
- [ ] He actualizado el `README.md` / `CHANGELOG.md` si aplica.
- [ ] Los cambios respetan el principio de **uso autorizado** del proyecto.

## Notas para el revisor

<!-- Contexto adicional, capturas, o cómo probarlo. -->
